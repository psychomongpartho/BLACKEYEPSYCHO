All credits goto orignal BlackEye-Python code https://github.com/M4cs/BlackEye-Python
The installation of this script is simple, open the terminal and run the below line.
```
wget https://raw.githubusercontent.com/amanverasia/BlackEye-Python/master/install.sh &&  bash install.sh
```
