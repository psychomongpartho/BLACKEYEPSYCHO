sudo apt install git php python3 openssh-server -y
cd ~/.ssh && ssh-keygen
